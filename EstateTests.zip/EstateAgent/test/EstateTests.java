import estateagent.EstateAgent;
import static org.junit.Assert.assertEquals;
import org.junit.Test;

/**
 *
 * @author: Abdul Baari Davids
 */
public class EstateTests {
    
    
    @Test    // if the calculateTotalSales method returns the correct total sales
    public void calculateTotalSales_ReturnsTotalSales() {
        // create an instance of EstateAgent with sample data
        EstateAgent estateAgent = new EstateAgent(new String[]{"Agent1"}, new double[][]{{100000, 200000, 300000}});

        double result = estateAgent.estateAgentSales(new double[]{100000, 200000, 300000});
        
        assertEquals(600000, result, 0.001);
    }

    
    
    
    @Test     // to check if the calculateTotalCommission method returns the correct commission
    public void calculateTotalCommission_ReturnsCommission() {
        // create an instance of EstateAgent with sample data
        EstateAgent estateAgent = new EstateAgent(new String[]{"Agent1"}, new double[][]{{100000, 200000, 300000}});
        
        double totalSales = estateAgent.estateAgentSales(new double[]{100000, 200000, 300000});
        double result = estateAgent.estateAgentCommission(totalSales);
        
        assertEquals(12000, result, 0.001);
    }

    
    
    
    
    
    
    

    @Test     //  check if the topAgent method returns the correct top-performing agent index
    public void topAgent_ReturnsTopPosition() {
        EstateAgent estateAgent = new EstateAgent(new String[]{"Agent1", "Agent2"}, 
                                                  new double[][]{{100000, 200000, 300000}, {200000, 300000, 400000}});
        
        double[] totalSales = {
            estateAgent.estateAgentSales(new double[]{100000, 200000, 300000}),
            estateAgent.estateAgentSales(new double[]{200000, 300000, 400000})
        };
        int result = estateAgent.topEstateAgent(totalSales);
        
        assertEquals(1, result);
    }
}
