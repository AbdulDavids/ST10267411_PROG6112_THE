package estateagent;

/**
 *
 * @author Abdul Baari Davids
 */
public interface IEstateAgent {
    double estateAgentSales(double[] propertySales);
    double estateAgentCommission(double propertySales);
    int topEstateAgent(double[] totalSales);
}

