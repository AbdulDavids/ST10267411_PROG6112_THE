package estategui;

/**
 *
 * @author Abdul Baari Davids
 */
public interface IEstateAgent {
    double calculateCommission(double propertyPrice, double agentCommission);
    boolean validateData(String location, String agentName, double propertyPrice, double agentCommission);
}

