package estategui;

import javax.swing.*;
import java.awt.*;
import java.io.FileWriter;
import java.io.IOException;

public class EstateAgentApp extends JFrame {
    // Declare GUI components
    private JTextField agentNameField, propertyPriceField, commissionPercentageField;
    private JComboBox<String> locationComboBox;
    private JTextArea reportTextArea;

    // Declare an instance of the estate agent interface
    private IEstateAgent estateAgent;

    // Constructor for the EstateAgentApp class, sets up the Jframe app
    public EstateAgentApp() {
        // Initialize the estate agent
        estateAgent = new EstateAgent();

        try {
            // Set UI to windows
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }

        // init JFrame
        setTitle("Estate Agent Commission Calculator");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(new Dimension(800, 1200));

        // Create and set up the layout manager
        setLayout(new BorderLayout());

        // init components
        locationComboBox = new JComboBox<>(new String[]{"Cape Town", "Durban", "Pretoria"});
        agentNameField = new JTextField();
        propertyPriceField = new JTextField();
        commissionPercentageField = new JTextField();
        reportTextArea = new JTextArea();
        reportTextArea.setEditable(false); // Make the text area read-only

        // create labels for components
        JLabel locationLabel = new JLabel("Location:");
        JLabel agentNameLabel = new JLabel("Agent Name:");
        JLabel propertyPriceLabel = new JLabel("Property Price:");
        JLabel commissionPercentageLabel = new JLabel("Commission Percentage:");

        // create a panel for input components
        JPanel inputPanel = new JPanel(new GridLayout(4, 2));
        inputPanel.add(locationLabel);
        inputPanel.add(locationComboBox);
        inputPanel.add(agentNameLabel);
        inputPanel.add(agentNameField);
        inputPanel.add(propertyPriceLabel);
        inputPanel.add(propertyPriceField);
        inputPanel.add(commissionPercentageLabel);
        inputPanel.add(commissionPercentageField);

        // add components to the JFrame
        add(inputPanel, BorderLayout.NORTH);
        add(new JScrollPane(reportTextArea), BorderLayout.CENTER);

        // init menu bar
        JMenuBar menuBar = new JMenuBar();
        setJMenuBar(menuBar);
        JMenu fileMenu = new JMenu("File");
        JMenu toolsMenu = new JMenu("Tools");

        // add menus to the menu bar
        menuBar.add(fileMenu);
        menuBar.add(toolsMenu);

        // create menu items
        JMenuItem exitMenuItem = new JMenuItem("Exit");
        JMenuItem processReportMenuItem = new JMenuItem("Process Report");
        JMenuItem clearMenuItem = new JMenuItem("Clear");
        JMenuItem saveReportMenuItem = new JMenuItem("Save Report");

        // add menu item buttons
        fileMenu.add(exitMenuItem);
        toolsMenu.add(processReportMenuItem);
        toolsMenu.add(clearMenuItem);
        toolsMenu.add(saveReportMenuItem);

        // action listeners
        exitMenuItem.addActionListener(e -> System.exit(0));
        processReportMenuItem.addActionListener(e -> processReport());
        clearMenuItem.addActionListener(e -> clearFields());
        saveReportMenuItem.addActionListener(e -> saveReport());

        pack(); // makes app not be small
    }

    
    
    
    
    // processs the report
    private void processReport() {
        // get input data 
        String location = (String) locationComboBox.getSelectedItem();
        String agentName = agentNameField.getText();
        double propertyPrice = Double.parseDouble(propertyPriceField.getText());
        double commissionPercentage = Double.parseDouble(commissionPercentageField.getText());

        // validate data
        if (estateAgent.validateData(location, agentName, propertyPrice, commissionPercentage)) {
            // Calculate commission
            double commission = estateAgent.calculateCommission(propertyPrice, commissionPercentage);

            // display report
            reportTextArea.setText("AGENT LOCATION: " + location + "\nAGENT NAME: " + agentName +
                    "\nPROPERTY PRICE: R" + propertyPrice + "\nCOMMISSION PERCENTAGE: " + commissionPercentage + "%" +
                    "\nCALCULATED COMMISSION: R" + commission);
        } else {
            // display an error message if valid fails
            JOptionPane.showMessageDialog(this, "Invalid data. Please check your input.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    
    
    
    
    
    // Method to clear input fields
    private void clearFields() {
        agentNameField.setText("");
        propertyPriceField.setText("");
        commissionPercentageField.setText("");
        reportTextArea.setText("");
    }

    
    
    
    
    
    // saves the report to a text file
    private void saveReport() {
        // Save the report to a text file in the project directory (report.txt)
        String filePath = System.getProperty("user.dir") + "/report.txt";

        StringBuilder report = new StringBuilder();

        report.append("ESTATE AGENT REPORT\n*****************************************\n");

        report.append(reportTextArea.getText());

        report.append("\n*****************************************");

        try (FileWriter writer = new FileWriter(filePath)) {
            writer.write(report.toString());
            JOptionPane.showMessageDialog(this, "Report saved successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);
        } catch (IOException e) {
            // Display an error message if there's an issue saving the report
            JOptionPane.showMessageDialog(this, "Error saving report.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
