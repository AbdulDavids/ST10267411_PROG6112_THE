import estategui.EstateAgent;
import estategui.IEstateAgent;


import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Abdul Baari Davids
 */
import org.junit.Test;


public class EstateAgentTest {
    
    // Test  successful commission calculation
    @Test
    public void calculateCommission_CalculatedSuccessfully() {
        EstateAgent estateAgent = new EstateAgent();
        double result = estateAgent.calculateCommission(100000.0, 5.0);
        assertEquals(5000.0, result, 0.01);
    }

    // Test unsuccessful commission calculation
    @Test
    public void calculateCommission_CalculatedUnsuccessfully() {
        IEstateAgent estateAgent = new EstateAgent();
        double result = estateAgent.calculateCommission(100000.0, -5.0);
        assertNotEquals(0.0, result, 0.01);
    }
    
    // validating input data with valid data
    @Test
    public void validateData_ValidData() {
        EstateAgent estateAgent = new EstateAgent();
        assertTrue(estateAgent.validateData("Cape Town", "John Doe", 150000.0, 3.5));
    }

    // validating input data with an invalid location
    @Test
    public void validateData_InvalidLocation() {
        EstateAgent estateAgent = new EstateAgent();
        assertFalse(estateAgent.validateData("", "John Doe", 150000.0, 3.5));
    }

    // validating input data with an invalid agent name
    @Test
    public void validateData_InvalidAgentName() {
        EstateAgent estateAgent = new EstateAgent();
        assertFalse(estateAgent.validateData("Cape Town", "", 150000.0, 3.5));
    }

    // validating input data with an invalid property price 
    @Test
    public void validateData_InvalidPropertyPrice() {
        EstateAgent estateAgent = new EstateAgent();
        assertFalse(estateAgent.validateData("Cape Town", "John Doe", 0.0, 3.5));
    }

    // validating input data with an invalid commission percentage
    @Test
    public void validateData_InvalidCommission() {
        EstateAgent estateAgent = new EstateAgent();
        assertFalse(estateAgent.validateData("Cape Town", "John Doe", 150000.0, -3.5));
    }
}
