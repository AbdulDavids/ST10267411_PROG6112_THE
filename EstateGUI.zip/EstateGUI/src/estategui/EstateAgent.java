package estategui;

/**
 *
 * @author Abdul Baari Davids
 */
public class EstateAgent implements IEstateAgent {
    
    // returns comssion
    @Override
    public double calculateCommission(double propertyPrice, double agentCommission) {
        return propertyPrice * (agentCommission / 100);
    }

    // validates data
    @Override
    public boolean validateData(String location, String agentName, double propertyPrice, double agentCommission) {

        return !location.isEmpty() && !agentName.isEmpty() && propertyPrice > 0 && agentCommission > 0;
    }
}
