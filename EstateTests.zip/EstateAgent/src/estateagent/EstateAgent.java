package estateagent;

/**
 * The EstateAgent class implements the IEstateAgent interface
 * and provides methods to calculate estate agent sales, estate agent commission,
 * and find the top-performing estate agent.
 */
public class EstateAgent implements IEstateAgent {
    private String[] agentNames;
    private double[][] propertySales;

    // Constructor to initialize agent names and property sales
    public EstateAgent(String[] agentNames, double[][] propertySales) {
        this.agentNames = agentNames;
        this.propertySales = propertySales;
    }

    
    
    
    
    // Calculate total sales for a given set of property sales
    @Override
    public double estateAgentSales(double[] propertySales) {
        double totalSales = 0;
        for (double sale : propertySales) {
            totalSales += sale;
        }
        return totalSales;
    }

 
    
    // Calculate estate agent commission based on total sales
    @Override
    public double estateAgentCommission(double totalSales) {
        return 0.02 * totalSales;
    }

  
    
    
    // Find the index of the top-performing estate agent
    @Override
    public int topEstateAgent(double[] totalSales) {
        int topAgentIndex = 0;
        double maxSales = totalSales[0];

        for (int i = 1; i < totalSales.length; i++) {
            if (totalSales[i] > maxSales) {
                maxSales = totalSales[i];
                topAgentIndex = i;
            }
        }
        return topAgentIndex;
    }

    
    
    
    // Generate a sales report in a formatted string
    public String generateReport() {
        
        StringBuilder report = new StringBuilder();

        double[] totalSales = new double[agentNames.length];
        double[] commissions = new double[agentNames.length];


        report.append("\nESTATE AGENTS SALES REPORT\n");
        report.append(String.format("%-15s%-15s%-15s%-15s\n", "Agent", "JAN", "FEB", "MAR"));
        report.append("--------------------------------------------------------\n");

        // calculate monthly sales, total sales, and commissions for each agent
        for (int i = 0; i < agentNames.length; i++) {
            double agentTotal = 0;
            report.append(String.format("%-15s", agentNames[i]));

            for (int j = 0; j < propertySales[i].length; j++) {
                report.append(String.format("%-15.0f", propertySales[i][j]));
                totalSales[i] += propertySales[i][j];
                agentTotal += propertySales[i][j];
            }

            report.append("\n");
            commissions[i] = estateAgentCommission(agentTotal);
        }

        // display total property sales for each agent
        for (int i = 0; i < agentNames.length; i++) {
            report.append("\nTotal property sales for ").append(agentNames[i]).append(": ").append(totalSales[i]);
        }

        report.append("\n");

        // display sales commission for each agent
        for (int i = 0; i < agentNames.length; i++) {
            report.append("\nSales Commission for ").append(agentNames[i]).append(": ").append(commissions[i]);
        }

        // display the top agent
        int topAgentIndex = topEstateAgent(totalSales);
        report.append("\n\nTop Performing Agent: ").append(agentNames[topAgentIndex]);

        return report.toString();
    }
}
