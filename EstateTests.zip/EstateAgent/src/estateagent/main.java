package estateagent;

/**
 *
 * @author Abdul Baari Davids
 */

public class main {
    public static void main(String[] args) {
        String[] agentNames = {"Joe Bloggs", "Jane Doe"};
        double[][] propertySales = {
                {800000, 1500000, 2000000},
                {700000, 1200000, 1600000}
        };

        EstateAgent estateAgent = new EstateAgent(agentNames, propertySales);
        String report = estateAgent.generateReport();
        
        System.out.println(report);
    }
}