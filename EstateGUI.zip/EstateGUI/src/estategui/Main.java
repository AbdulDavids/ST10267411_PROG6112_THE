package estategui;

import javax.swing.SwingUtilities;

/**
 *
 * @author Abdul Baari Davids
 */
public class Main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            EstateAgentApp app = new EstateAgentApp();
            app.setVisible(true);
        });
    } }
